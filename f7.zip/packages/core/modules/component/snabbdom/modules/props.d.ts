import { Module } from './module';
export declare type Props = Record<string, any>;
export declare const propsModule: Module;
export default propsModule;
