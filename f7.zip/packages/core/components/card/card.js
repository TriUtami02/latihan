export default {
  name: 'card',
};
